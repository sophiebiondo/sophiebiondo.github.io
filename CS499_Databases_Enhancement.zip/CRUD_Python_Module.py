import pandas as pd
from AnimalAnalytics import AnimalAnalytics

class AnimalShelter:
    """
    A CSV‑backed CRUD module that simulates database operations
    for the AAC animal shelter dataset.

    This class abstracts data loading, modification, and persistence,
    providing a clean interface for Create, Read, Update, and Delete
    operations. It also exposes analytics integration through a
    dedicated accessor method.
    """

    def __init__(self, csv_path="aac_shelter_outcomes.csv"):
        """
        Initialize the CRUD module by loading the CSV into memory.

        Parameters:
            csv_path (str): Path to the CSV file containing shelter data.

        The dataset is stored internally as a pandas DataFrame.
        """
        self.csv_path = csv_path
        self.df = pd.read_csv(csv_path)

    # -------------------------------------------------------------
    # CREATE
    # -------------------------------------------------------------
    def create(self, data: dict):
        """
        Insert a new record into the dataset.

        Parameters:
            data (dict): A dictionary representing a new animal record.

        Behavior:
            - Appends the new record to the DataFrame.
            - Writes the updated DataFrame back to the CSV.

        Returns:
            True on success.
        """
        self.df = pd.concat([self.df, pd.DataFrame([data])], ignore_index=True)
        self.df.to_csv(self.csv_path, index=False)
        return True

    # -------------------------------------------------------------
    # READ
    # -------------------------------------------------------------
    def read(self, query: dict):
        """
        Retrieve records matching the query.

        Parameters:
            query (dict): Key-value pairs to filter the dataset.
                          Example: {"breed": "Labrador Retriever Mix"}

        Behavior:
            - If query is empty, returns all records.
            - Otherwise, performs exact-match filtering on each key.

        Returns:
            A list of dictionaries representing matching records.
        """
        if not query:
            return self.df.to_dict(orient="records")

        # Start with a mask of all True values
        mask = pd.Series([True] * len(self.df))

        # Apply each filter condition
        for k, v in query.items():
            mask &= self.df[k] == v

        return self.df[mask].to_dict(orient="records")

    # -------------------------------------------------------------
    # UPDATE
    # -------------------------------------------------------------
    def update(self, query: dict, new_values: dict):
        """
        Update records that match the query.

        Parameters:
            query (dict): Conditions to identify target rows.
            new_values (dict): Columns and values to update.

        Behavior:
            - Locates rows matching the query.
            - Applies updates to those rows.
            - Saves the modified DataFrame back to the CSV.

        Returns:
            True on success.
        """
        mask = pd.Series([True] * len(self.df))
        for k, v in query.items():
            mask &= self.df[k] == v

        for col, val in new_values.items():
            self.df.loc[mask, col] = val

        self.df.to_csv(self.csv_path, index=False)
        return True

    # -------------------------------------------------------------
    # DELETE
    # -------------------------------------------------------------
    def delete(self, query: dict):
        """
        Delete records that match the query.

        Parameters:
            query (dict): Conditions to identify rows to remove.

        Behavior:
            - Filters out rows matching the query.
            - Saves the updated DataFrame back to the CSV.

        Returns:
            True on success.
        """
        mask = pd.Series([True] * len(self.df))
        for k, v in query.items():
            mask &= self.df[k] == v

        self.df = self.df[~mask]
        self.df.to_csv(self.csv_path, index=False)
        return True

    # -------------------------------------------------------------
    # ANALYTICS INTEGRATION
    # -------------------------------------------------------------
    def get_dataframe(self):
        """
        Provide a safe copy of the internal DataFrame.

        Purpose:
            - Prevents analytics operations from mutating CRUD state.
            - Supports separation of concerns between CRUD and analytics.

        Returns:
            A copy of the current DataFrame.
        """
        return self.df.copy()

    def get_analytics(self):
        """
        Create and return an AnimalAnalytics instance initialized
        with the current dataset.

        This method cleanly connects the CRUD layer to the analytics
        layer without creating circular dependencies.

        Returns:
            AnimalAnalytics: analytics object operating on a DataFrame copy.
        """
        return AnimalAnalytics(self.get_dataframe())