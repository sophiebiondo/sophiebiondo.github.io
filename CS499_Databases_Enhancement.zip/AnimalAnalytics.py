import pandas as pd

class AnimalAnalytics:
    """
    Analytics module designed specifically for the AAC CSV dataset.
    Provides adoption rates, seasonal outcome trends, age distribution,
    and a simple predictive scoring heuristic.
    """

    def __init__(self, dataframe: pd.DataFrame):
        self.df = dataframe.copy()

        # Check that datetime column is parsed
        if "datetime" in self.df.columns:
            self.df["datetime"] = pd.to_datetime(self.df["datetime"], errors="coerce")

    # -------------------------------------------------------------
    # Adoption Rate by Breed
    # -------------------------------------------------------------
    def compute_adoption_rate(self):
        """
        Returns a DataFrame showing the number of adoptions per breed,
        sorted from most adopted to least.
        """
        if "outcome_type" not in self.df.columns or "breed" not in self.df.columns:
            raise ValueError("Required columns missing: outcome_type, breed")

        adopted = self.df[self.df["outcome_type"] == "Adoption"]
        result = (
            adopted.groupby("breed")
            .size()
            .reset_index(name="adoption_count")
            .sort_values(by="adoption_count", ascending=False)
        )
        return result

    # -------------------------------------------------------------
    # Seasonal Outcome Trends
    # -------------------------------------------------------------
    def seasonal_outcome_trends(self):
        """
        Groups animals by outcome month and counts how many outcomes
        occurred in each month.
        """
        if "datetime" not in self.df.columns:
            raise ValueError("Required column missing: datetime")

        self.df["outcome_month"] = self.df["datetime"].dt.month
        result = (
            self.df.groupby("outcome_month")
            .size()
            .reset_index(name="outcome_count")
            .sort_values(by="outcome_month")
        )
        return result

    # -------------------------------------------------------------
    # Age Distribution
    # -------------------------------------------------------------
    def age_distribution(self):
        """
        Returns a DataFrame showing the distribution of ages (in weeks)
        for animals at the time of outcome.
        """
        if "age_upon_outcome_in_weeks" not in self.df.columns:
            raise ValueError("Required column missing: age_upon_outcome_in_weeks")

        result = (
            self.df["age_upon_outcome_in_weeks"]
            .dropna()
            .astype(float)
            .describe()
            .to_frame(name="age_statistics")
        )
        return result

    # -------------------------------------------------------------
    # Predict Adoption Likelihood
    # -------------------------------------------------------------
    def predict_adoption_likelihood(self, animal: dict):
        """
        A scoring system that estimates how likely an animal is
        to be adopted based on age, breed demand, and sex.
        """
        score = 0

        # Age factor (younger animals tend to be adopted more quickly)
        if "age_upon_outcome_in_weeks" in animal and pd.notna(animal["age_upon_outcome_in_weeks"]):
            if animal["age_upon_outcome_in_weeks"] < 12:
                score += 3
            elif animal["age_upon_outcome_in_weeks"] < 52:
                score += 2
            else:
                score += 1

        # Breed demand factor
        high_demand_breeds = [
            "Labrador Retriever Mix",
            "German Shepherd Mix",
            "Pit Bull Mix",
            "Chihuahua Mix",
            "Domestic Shorthair"
        ]
        if "breed" in animal and animal["breed"] in high_demand_breeds:
            score += 3

        # Sex factor (neutered/spayed animals often adopted faster)
        if "sex_upon_outcome" in animal:
            if "Neutered" in animal["sex_upon_outcome"] or "Spayed" in animal["sex_upon_outcome"]:
                score += 2

        return score