#pragma once
#ifndef APPLICATIONCONTROLLER_H
#define APPLICATIONCONTROLLER_H

#include <string>
#include "FileManager.h"
#include "XOREncryption.h"
#include "IntegrityChecker.h"

class ApplicationController {
public:
    void run();

private:
    const std::string input_file = "inputdatafile.txt";
    const std::string encrypted_file = "encrypteddatafile.txt";
    const std::string decrypted_file = "decrypteddatafile.txt";
    const std::string key = "password";

    FileManager file_manager;
    XOREncryption encryption;
    IntegrityChecker integrity_checker;
};

#endif // APPLICATIONCONTROLLER_H