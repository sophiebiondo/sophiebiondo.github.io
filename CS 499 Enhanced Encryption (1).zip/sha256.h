#pragma once

#ifndef SHA256_H
#define SHA256_H

#include <string>
#include <cstring>
#include <sstream>
#include <iomanip>
#include <vector>

class SHA256 {
public:
    SHA256() { reset(); }

    void update(const unsigned char* data, size_t len) {
        for (size_t i = 0; i < len; ++i) {
            data_buffer[data_len] = data[i];
            data_len++;
            if (data_len == 64) {
                transform();
                bit_len += 512;
                data_len = 0;
            }
        }
    }

    void update(const std::string& data) {
        update(reinterpret_cast<const unsigned char*>(data.c_str()), data.size());
    }

    std::string final() {
        uint32_t i = data_len;

        // Pad whatever data is left in the buffer.
        if (data_len < 56) {
            data_buffer[i++] = 0x80;
            while (i < 56) {
                data_buffer[i++] = 0x00;
            }
        }
        else {
            data_buffer[i++] = 0x80;
            while (i < 64) {
                data_buffer[i++] = 0x00;
            }
            transform();
            std::memset(data_buffer, 0, 56);
        }

        bit_len += data_len * 8;
        data_buffer[63] = bit_len;
        data_buffer[62] = bit_len >> 8;
        data_buffer[61] = bit_len >> 16;
        data_buffer[60] = bit_len >> 24;
        data_buffer[59] = bit_len >> 32;
        data_buffer[58] = bit_len >> 40;
        data_buffer[57] = bit_len >> 48;
        data_buffer[56] = bit_len >> 56;
        transform();

        std::ostringstream result;
        for (int i = 0; i < 8; ++i) {
            result << std::hex << std::setw(8) << std::setfill('0') << state[i];
        }

        reset();
        return result.str();
    }

private:
    uint8_t data_buffer[64];
    uint32_t data_len;
    uint64_t bit_len;
    uint32_t state[8];

    static uint32_t rotr(uint32_t x, uint32_t n) {
        return (x >> n) | (x << (32 - n));
    }

    static uint32_t choose(uint32_t e, uint32_t f, uint32_t g) {
        return (e & f) ^ (~e & g);
    }

    static uint32_t majority(uint32_t a, uint32_t b, uint32_t c) {
        return (a & b) ^ (a & c) ^ (b & c);
    }

    static uint32_t sig0(uint32_t x) {
        return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22);
    }

    static uint32_t sig1(uint32_t x) {
        return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25);
    }

    static uint32_t theta0(uint32_t x) {
        return rotr(x, 7) ^ rotr(x, 18) ^ (x >> 3);
    }

    static uint32_t theta1(uint32_t x) {
        return rotr(x, 17) ^ rotr(x, 19) ^ (x >> 10);
    }

    void reset() {
        data_len = 0;
        bit_len = 0;
        state[0] = 0x6a09e667;
        state[1] = 0xbb67ae85;
        state[2] = 0x3c6ef372;
        state[3] = 0xa54ff53a;
        state[4] = 0x510e527f;
        state[5] = 0x9b05688c;
        state[6] = 0x1f83d9ab;
        state[7] = 0x5be0cd19;
    }

    void transform() {
        static const uint32_t k[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
        };

        uint32_t m[64];
        for (uint32_t i = 0, j = 0; i < 16; ++i, j += 4) {
            m[i] = (data_buffer[j] << 24) |
                (data_buffer[j + 1] << 16) |
                (data_buffer[j + 2] << 8) |
                (data_buffer[j + 3]);
        }

        for (uint32_t i = 16; i < 64; ++i) {
            m[i] = theta1(m[i - 2]) + m[i - 7] + theta0(m[i - 15]) + m[i - 16];
        }

        uint32_t a = state[0];
        uint32_t b = state[1];
        uint32_t c = state[2];
        uint32_t d = state[3];
        uint32_t e = state[4];
        uint32_t f = state[5];
        uint32_t g = state[6];
        uint32_t h = state[7];

        for (uint32_t i = 0; i < 64; ++i) {
            uint32_t t1 = h + sig1(e) + choose(e, f, g) + k[i] + m[i];
            uint32_t t2 = sig0(a) + majority(a, b, c);
            h = g;
            g = f;
            f = e;
            e = d + t1;
            d = c;
            c = b;
            b = a;
            a = t1 + t2;
        }

        state[0] += a;
        state[1] += b;
        state[2] += c;
        state[3] += d;
        state[4] += e;
        state[5] += f;
        state[6] += g;
        state[7] += h;
    }
};

inline std::string sha256(const std::string& data) {
    SHA256 ctx;
    ctx.update(data);
    return ctx.final();
}

#endif // SHA256_H