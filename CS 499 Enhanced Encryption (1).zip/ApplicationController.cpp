/***
    ApplicationController.cpp
   
    This file implements the ApplicationController class, which coordinates
    the entire workflow of the program. It acts as the central orchestrator,
    delegating responsibilities to FileManager, XOREncryption, and
    IntegrityChecker.

    Functional Responsibilities:
    - Reads the input file and extracts metadata.
    - Encrypts the file contents and writes the encrypted output.
    - Decrypts the encrypted data and writes the decrypted output.
    - Computes SHA-256 hashes for original and decrypted data.
    - Performs integrity verification and reports the result.
    - Handles exceptions and provides user-facing status messages.
***/

#include "ApplicationController.h"

#include <iostream>
#include <stdexcept>

void ApplicationController::run() {
    try {
        std::cout << "Encryption Decryption with Integrity Check\n";

        std::string file_data = file_manager.read_file(input_file);
        std::string student_name = file_manager.extract_student_name(file_data);

        std::string encrypted = encryption.encrypt(file_data, key);
        file_manager.write_file(encrypted_file, student_name, key, encrypted);

        std::string decrypted = encryption.decrypt(encrypted, key);
        file_manager.write_file(decrypted_file, student_name, key, decrypted);

        std::string original_hash = integrity_checker.compute_hash(file_data);
        std::string decrypted_hash = integrity_checker.compute_hash(decrypted);

        std::string result = integrity_checker.verify(original_hash, decrypted_hash);

        std::cout << "Read File: " << input_file
            << " - Encrypted To: " << encrypted_file
            << " - Decrypted To: " << decrypted_file << "\n";

        std::cout << "Integrity Check Result: " << result << "\n";
    }
    catch (const std::exception& ex) {
        std::cerr << "Error occurred: " << ex.what() << "\n";
    }
}