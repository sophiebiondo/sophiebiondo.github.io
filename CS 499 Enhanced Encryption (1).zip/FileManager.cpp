/***
    FileManager.cpp

    This file implements the FileManager class, which centralizes all file
    input/output operations for the application. By isolating file handling
    in a dedicated class, the program becomes easier to maintain and
    extend.

    Functional Responsibilities:
    - read_file(): Loads an entire file into a string using safe, exception-
      based error handling.
    - write_file(): Saves encrypted or decrypted output using the required
      metadata format (student name, timestamp, key, data).
    - extract_student_name(): Retrieves the first line of the input file,
      which contains the student name.

***/

#include "FileManager.h"

#include <fstream>
#include <sstream>
#include <stdexcept>
#include <ctime>

std::string FileManager::read_file(const std::string& filename) const {
    std::ifstream in(filename, std::ios::in | std::ios::binary);
    if (!in) {
        throw std::runtime_error("Unable to open input file: " + filename);
    }

    std::ostringstream buffer;
    buffer << in.rdbuf();
    return buffer.str();
}

void FileManager::write_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data) const {
    std::ofstream out(filename, std::ios::out | std::ios::binary);
    if (!out) {
        throw std::runtime_error("Unable to open output file: " + filename);
    }

    std::time_t t = std::time(nullptr);
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char date_buf[11];
    std::strftime(date_buf, sizeof(date_buf), "%Y-%m-%d", &tm);

    out << student_name << "\n";
    out << date_buf << "\n";
    out << key << "\n";
    out << data << "\n";
}

std::string FileManager::extract_student_name(const std::string& data) const {
    std::string student_name;
    size_t pos = data.find('\n');
    if (pos != std::string::npos) {
        student_name = data.substr(0, pos);
    }
    return student_name;
}