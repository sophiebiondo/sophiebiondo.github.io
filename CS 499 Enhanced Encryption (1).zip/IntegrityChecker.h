#pragma once
#ifndef INTEGRITYCHECKER_H
#define INTEGRITYCHECKER_H

#include <string>

class IntegrityChecker {
public:
    std::string compute_hash(const std::string& data) const;

    std::string verify(const std::string& original_hash,
        const std::string& decrypted_hash) const;
};

#endif // INTEGRITYCHECKER_H