#pragma once
#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>

class FileManager {
public:
    std::string read_file(const std::string& filename) const;

    void write_file(const std::string& filename,
        const std::string& student_name,
        const std::string& key,
        const std::string& data) const;

    std::string extract_student_name(const std::string& data) const;
};

#endif // FILEMANAGER_H