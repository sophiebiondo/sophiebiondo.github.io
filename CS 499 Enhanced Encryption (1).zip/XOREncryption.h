#pragma once
#ifndef XO R ENCRYPTION_H
#define XO R ENCRYPTION_H

#include "EncryptionAlgorithm.h"

class XOREncryption : public EncryptionAlgorithm {
public:
    std::string encrypt(const std::string& data,
        const std::string& key) const override;

    std::string decrypt(const std::string& data,
        const std::string& key) const override;

private:
    std::string xor_process(const std::string& data,
        const std::string& key) const;
};

#endif // XOR_ENCRYPTION_H