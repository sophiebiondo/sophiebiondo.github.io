/***
    IntegrityChecker.cpp

    This file implements the IntegrityChecker class, which provides hashing
    and integrity verification for the application. It uses a SHA-256 hashing
    function to check that decrypted data matches the original input.

    Functional Responsibilities:
    - compute_hash(): Produces a SHA-256 hash of the provided data string.
    - verify(): Compares the original and decrypted hashes and returns a
      human-readable integrity status.
***/

#include "IntegrityChecker.h"
#include "sha256.h"

std::string IntegrityChecker::compute_hash(const std::string& data) const {
    return sha256(data);
}

std::string IntegrityChecker::verify(const std::string& original_hash,
    const std::string& decrypted_hash) const {
    if (original_hash == decrypted_hash) {
        return "Integrity Verified";
    }
    return "Integrity Check Failed";
}