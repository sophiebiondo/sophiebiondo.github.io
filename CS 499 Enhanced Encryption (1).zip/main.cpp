/***
    main.cpp

    Entry point of the application. Its sole responsibility is to instantiate
    the ApplicationController and invoke its run() method.

    Architectural Role:
    Keeping main() minimal reflects a clean, modular design. All program
    logic is delegated to ApplicationController, in order for the entry
    point to remain simple and aligned with professional standards.

***/

#include "ApplicationController.h"

int main() {
    ApplicationController controller;
    controller.run();
    return 0;
}