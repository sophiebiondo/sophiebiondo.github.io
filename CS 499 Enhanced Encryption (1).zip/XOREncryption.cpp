/***
    XOREncryption.cpp

    This file implements the XOREncryption class, which provides a
    encryption algorithm based on a simple XOR cipher. Although XOR is not
    cryptographically secure, it is retained for backward compatibility with
    the original program.

    Functional Responsibilities:
    - Implements the EncryptionAlgorithm interface.
    - Provides encrypt() and decrypt() methods that both rely on the same
      XOR transformation.
    - Encapsulates the xor_process() helper to keep encryption logic isolated
      and maintain a clean separation of concerns.
***/

#include "XOREncryption.h"
#include <cassert>

std::string XOREncryption::xor_process(const std::string& data,
    const std::string& key) const {
    const auto key_length = key.length();
    const auto data_length = data.length();

    assert(key_length > 0);
    assert(data_length > 0);

    std::string output = data;

    for (size_t i = 0; i < data_length; ++i) {
        output[i] = data[i] ^ key[i % key_length];
    }

    assert(output.length() == data_length);
    return output;
}

std::string XOREncryption::encrypt(const std::string& data,
    const std::string& key) const {
    return xor_process(data, key);
}

std::string XOREncryption::decrypt(const std::string& data,
    const std::string& key) const {
    return xor_process(data, key);
}