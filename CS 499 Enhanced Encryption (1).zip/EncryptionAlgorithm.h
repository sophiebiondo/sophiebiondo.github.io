#pragma once
#ifndef ENCRYPTIONALGORITHM_H
#define ENCRYPTIONALGORITHM_H

#include <string>

class EncryptionAlgorithm {
public:
    virtual ~EncryptionAlgorithm() = default;

    virtual std::string encrypt(const std::string& data,
        const std::string& key) const = 0;

    virtual std::string decrypt(const std::string& data,
        const std::string& key) const = 0;
};

#endif // ENCRYPTIONALGORITHM_H