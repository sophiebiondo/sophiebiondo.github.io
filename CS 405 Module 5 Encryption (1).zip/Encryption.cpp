// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR each character with the corresponding key character (cycling with modulo)
        output[i] = source[i] ^ key[i % key_length];
    }

    // output length must equal source length
    assert(output.length() == source_length);

    return output;
}

/// <summary>
/// Load the entire file into a single string
/// </summary>
std::string read_file(const std::string& filename)
{
    std::ifstream in(filename, std::ios::in | std::ios::binary);
    if (!in)
    {
        throw std::runtime_error("Unable to open input file: " + filename);
    }

    std::ostringstream buffer;
    buffer << in.rdbuf(); // read whole file into buffer
    return buffer.str();
}

/// <summary>
/// Extract name from first line of file data
/// </summary>
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;
    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
    }
    return student_name;
}

/// <summary>
/// Save data file in required format:
/// Line 1: student name
/// Line 2: timestamp (yyyy-mm-dd)
/// Line 3: key used
/// Line 4+: data
/// </summary>
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream out(filename, std::ios::out | std::ios::binary);
    if (!out)
    {
        throw std::runtime_error("Unable to open output file: " + filename);
    }

    // get current date
    std::time_t t = std::time(nullptr);
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char date_buf[11]; // yyyy-mm-dd
    std::strftime(date_buf, sizeof(date_buf), "%Y-%m-%d", &tm);

    // write file format
    out << student_name << "\n";
    out << date_buf << "\n";
    out << key << "\n";
    out << data << "\n";
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name
        << " - Encrypted To: " << encrypted_file_name
        << " - Decrypted To: " << decrypted_file_name << std::endl;
}